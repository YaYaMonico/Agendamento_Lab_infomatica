package com.agendamento.yasmin.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.agendamento.yasmin.models.Reserva;

public interface RepositoryReserva extends JpaRepository<Reserva, Integer>{

}
