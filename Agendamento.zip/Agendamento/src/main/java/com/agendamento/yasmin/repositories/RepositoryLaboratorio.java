package com.agendamento.yasmin.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.agendamento.yasmin.models.Laboratorio;

public interface RepositoryLaboratorio extends JpaRepository<Laboratorio, Integer>{

}
